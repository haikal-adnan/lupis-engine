Top Down Credit Assets
https://limezu.itch.io/moderninteriors (Tile and Sprite)