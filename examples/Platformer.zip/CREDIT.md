Platformer Credit Assets
https://prinbles.itch.io/solid (User Interface)
https://pixelfrog-assets.itch.io/pixel-adventure-1 (Tile and Sprite)