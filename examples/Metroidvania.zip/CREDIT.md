Metroidvania Credit Assets
https://anokolisa.itch.io/sidescroller-pixelart-sprites-asset-pack-forest-16x16 (Tile and Sprite)