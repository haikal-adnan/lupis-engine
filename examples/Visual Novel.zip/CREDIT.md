Visual Novel Credit Assets

https://opengameart.org/content/woodland-fantasy (Song)
https://onelevelstudio.itch.io/dialogue-gui (User Interface)
https://the-cooked-works.itch.io/softline-ui-screens-free (User Interface)
https://natsuyacharacterart.itch.io/ribbon (Sprite)